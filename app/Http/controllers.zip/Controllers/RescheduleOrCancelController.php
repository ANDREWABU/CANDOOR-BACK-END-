<?php

namespace App\Http\Controllers;

use App\Models\RescheduleOrCancel;
use Illuminate\Http\Request;

class RescheduleOrCancelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\RescheduleOrCancel  $rescheduleOrCancel
     * @return \Illuminate\Http\Response
     */
    public function show(RescheduleOrCancel $rescheduleOrCancel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\RescheduleOrCancel  $rescheduleOrCancel
     * @return \Illuminate\Http\Response
     */
    public function edit(RescheduleOrCancel $rescheduleOrCancel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\RescheduleOrCancel  $rescheduleOrCancel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, RescheduleOrCancel $rescheduleOrCancel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\RescheduleOrCancel  $rescheduleOrCancel
     * @return \Illuminate\Http\Response
     */
    public function destroy(RescheduleOrCancel $rescheduleOrCancel)
    {
        //
    }
}
