<?php

namespace App\Http\Controllers;

use App\Models\Api\MentorExpertise;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class MentorExpertiseController extends Controller
{
    public function index()
    {
        $getmentorExpertise = MentorExpertise::where('mentor_id', Auth('api')->id())->get();
        return response()->json([
            'status'=>200,
            'success'=>'MentorExpertise successfully fetch',
            'WorkExperience'=>$getmentorExpertise
        ]);
    }

    public function store(Request $request)
    {
        Validator::make($request->all(),[
            'expertise'=>'required',
            'session_title'=>'required',
            'session_type'=>'required',
            'session_duration'=>'required',
            'session_price'=>'required',
        ])->validate();

//        DB::table('mentor_expertises')->where('mentor_id',Auth('api')->id())->delete();

        foreach($request->session_title as $key => $value)
        {
            $MentorExpertise = new MentorExpertise();
            $MentorExpertise->mentor_id = Auth('api')->id();
            $MentorExpertise->expertise=$request->expertise[$key];
            $MentorExpertise->session_title=$value;
            $MentorExpertise->session_type=$request->session_type[$key];
            $MentorExpertise->session_duration=$request->session_duration[$key];
            $MentorExpertise->session_price=$request->session_price[$key];
            $MentorExpertise->save();
        }

        $mentorExpertise = MentorExpertise::where('mentor_id', Auth('api')->id())->get();

//        foreach($mentorExpertise as $mE)
//        {
//            $mentorExpert[] =
//                [
//                'id' => $mE['id'],
//                'mentor_id' => $mE['mentor_id'],
//                'expertise' => $mE['expertise'],
//                'session_title' => $mE['session_title'],
//                'session_type' => $mE['session_type'],
//                'session_duration' => $mE['session_duration'],
//                'session_price' => $mE['session_price'],
//                ];
//
//        }

        return response()->json([
            'status' =>200,
            'success'=>'Record Successfully save',
            'personalInfo' => $mentorExpertise
        ]);
    }

    public function destroy(MentorExpertise $mentorExpertise)
    {
        $mentorExpertise->delete();
        return response()->json([
            'status' => 200,
            'success'=>'Record Successfully Deleted'
        ]);
    }

}
