<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;

class MailTestController extends Controller
{
    public function MailTest()
    {

        $data = array('name'=>"mail test");
        
        Mail::send(['text'=>'mail'], $data, function($message) {
            $message->to('rs9613609@gmail.com', 'Anshuman Sharma')->subject
                ('Laravel Basic Testing Mail');
            $message->from('xyz@gmail.com','Testing mail');
        });
        echo "Basic Email Sent. Check your inbox.";

    }
}
