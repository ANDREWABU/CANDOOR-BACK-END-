<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Api\JobPost;
use Illuminate\Http\Request;
use App\Models\Api\AppliedJob;
use Helpers;

class AppliedJobController extends Controller
{
    //

    public function store(Request $request)
    {
        $validate = $request->validate([
            'post_id' => 'required',
        ]);
        $user_id = auth('api')->id();
        $data = AppliedJob::create(array_merge($validate,['user_id' => Auth('api')->id()]));
        return Helpers::sendResponseBack($data, 'applied', 'Job Applied successfully created', 'Something Went wrong please try again');
    }

    public function getAppliedJobs()
    {
        $user_id = Auth('api')->id();
        $data = AppliedJob::with('post')->where('user_id',$user_id)->get();
        return Helpers::sendResponseBack($data, 'applied', 'Job Applied successfully retrieved', 'Something Went wrong please try again');
    }










}
