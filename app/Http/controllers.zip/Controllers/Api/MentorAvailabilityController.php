<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Api\MentorAvailability;
use App\Models\Day;
use App\Models\TimeZone;
use Helpers;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Carbon;

class MentorAvailabilityController extends Controller
{
    public function __Construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $user_id = Auth('api')->id();
        $days = Day::all();
        $data = MentorAvailability::where('mentor_id', $user_id)->with('zone')->with('day')->get();
        return Helpers::sendResponseBack($data, 'availability', 'Mentor Availability successfully retrieved', 'No Data Found');
    }

    public function store(Request $request)
    {
        $request->validate([
            'timeZone' => 'required',
            'daysDetail' => 'required',
        ]);

        $user_id = Auth('api')->id();
        TimeZone::where('user_id', $user_id)->delete();
        $timeZone = TimeZone::create([
            "user_id" => $user_id,
            "abbrev" => $request->timeZone['abbrev'],
            "altName" => $request->timeZone['altName'],
            "label" => $request->timeZone['label'],
            "offset" => $request->timeZone['offset'],
            "value" => $request->timeZone['value'],
        ]);
        MentorAvailability::where('mentor_id', $user_id)->delete();
        foreach ($request->daysDetail as $key => $val) {
            if(!empty($val)){
                foreach ($val as $k => $v) {
                    if (isset($v['start_time']) && isset($v['end_time'])) {
                        $day_id = $this->getDayIdByName($key);
                        MentorAvailability::create([
                            'mentor_id' => $user_id,
                            'zone_id' => $timeZone->id,
                            'day_id' => $day_id,
                            'start_time' => $v['start_time'],
                            'end_time' => $v['end_time'],
                        ]);
                    }
                }
            }
        }
        User::where('id',Auth('api')->id())->update(['profile_filled' => 1 ]);
        $data = MentorAvailability::where('mentor_id',$user_id)->with('zone')->get();
        return Helpers::sendResponseBack($data,'availability', 'Mentor Availability successfully retrieved', 'No Data Found');
    }

    public function update($id, Request $request)
    {
        dd($request->all());
    }

    public function destroy($id)
    {

    }

    public function getDayIdByName($val){
        switch ($val) {
            case "Monday":
                return 1;
            case "Tuesday":
                return 2;
            case "Wednesday":
                return 3;
            case "Thursday":
                return 4;
            case "Friday":
                return 5;
            case "Saturday":
                return 6;
            case "Sunday":
                return 7;

        }
    }
}
