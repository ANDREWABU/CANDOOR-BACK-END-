<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Api\JobPost;
use Illuminate\Http\Request;
use Helpers;

class ApplicantController extends Controller
{
    public function applicantOrder(Request $request, $id)
    {
        $jobpost = JobPost::find($id);
        $query = JobPost::with(['applicants' => function($q) use($request)
        {
            $q->orderBy('id',$request->sort)->menteeInfo();
        }
        ])->where('id', $jobpost->id)
            ->where('user_id',auth('api')->id())
            ->first();
        return Helpers::sendResponseBack($query, 'applicantLists', 'applicantLists successfully retrieved', 'Something Went wrong please try again');
    }

    public function jobApplicants($id){

        $jobpost = JobPost::find($id);

        if (is_object($jobpost))
        {
            $data = JobPost::
            with('applicants.personalInfo')
            ->with('applicants.education')
            ->with('applicants.skills')
            ->with('applicants.workExp')
            ->where('id',$jobpost->id)
            ->where('user_id',auth('api')->id())
            ->first();
            return Helpers::sendResponseBack($data, 'applied', 'Job Applicants successfully retrieved', 'Something Went wrong please try again');
        }
    }
}
