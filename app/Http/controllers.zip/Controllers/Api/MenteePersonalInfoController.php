<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Api\PersonalInformation;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class MenteePersonalInfoController extends Controller
{
    public function index()
    {
        $user_id = Auth('api')->id();
        $getPersonalInfo = PersonalInformation::
        where('user_id',Auth('api')->id())
            ->with('country')->with('city')
            ->with('skills')
            ->with('education')
            ->with('experience')
            ->get()
            ->toArray();
        return response()->json([
            'status' =>200,
            'success'=>"Record successfully fetch",
            'personalInfo'=> $getPersonalInfo
        ]);

    }


    public function store(Request $request)
    {
        Validator::make($request->all(),[

            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
        //          |email|unique:personal_information,email
            'country' =>'required',
        ])->validate();
        PersonalInformation::updateOrCreate(
            [
            'user_id' => Auth('api')->id(),
            'email' => $request->email
            ],
            [
            'country' => $request->country,
            'city' => $request->city,
        ]);
        // ,'first_name' => $request->first_name,'last_name' => $request->last_name
        User::where('id',Auth('api')->id())->update(['profile_filled' => 1]);
         $personalInfo = PersonalInformation::where('user_id',Auth('api')->id())->get();

         return response()->json([
             'status' =>200,
             'success'=>'Record Successfully save',
             'personalInfo'=> $personalInfo
         ]);

    }

    public function userInfo()
    {
        $user_id = Auth('api')->id();
        // \DB::enableQueryLog();
        $data = User::where('id',$user_id)->menteeInfo()->get()->toArray();
        return response()->json([
            'status' =>200,
            'success'=>'Record Successfully save',
            'userInfo'=> $data
        ]);
        // dd(\DB::getQueryLog());
        // dd($data);
    }
}
