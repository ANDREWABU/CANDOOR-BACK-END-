<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Api\MentorExpertiseDetailRepo;

class MentorExpertiseDetailController extends Controller
{
    /**
     * Auth Umar
    */

    /**
     * Repository
     * @var App\Repositories\Api\MentorExpertiseDetailRepo;
     */
    protected $repo;

    public function __construct(MentorExpertiseDetailRepo $repo)
    {
        $this->repo = $repo;
    }
}
