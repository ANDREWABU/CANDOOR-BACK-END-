<?php

namespace App\Http\Controllers\Api\V2\Advisee;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\EducationExperience;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\EducationExperienceResource;
use App\Http\Traits\Helpers\ApiResponseTrait;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;


class EducationExperienceController extends Controller
{
    use ApiResponseTrait;

    //
    public function add(Request $request){
        $request->validate([
            'school' => 'required|string',
            'degree' => 'required|string',
            'fields_of_study' => 'required|array',
            'graduation_year' => 'required|date',
        ]);

        
        
        $educationExperience = new EducationExperience();
        $educationExperience->school = $request->school;
        $educationExperience->degree = $request->degree;
        $educationExperience->fields_of_study = json_encode($request->fields_of_study);
        $educationExperience->AdviseeID = $request->user()->AdviseeID;
        $educationExperience->graduation_year = date('m/y',strtotime($request->graduation_year));
        $educationExperience->Created_timestamp_EST =  Carbon::parse(now(),'EST')->setTimeZone('EST');
        $educationExperience->Modified_timestamp_EST = Carbon::parse(now(),'EST')->setTimeZone('EST');
        $educationExperience->UserID = $request->user()->id;
        $educationExperience->save();

        $advisee=DB::table('advisees')->where('UserID',$request->user()->id);
        $advisee->update([            
            'education_experiences'=>json_encode($educationExperience->where('UserID',$request->user()->id)->pluck('EducationExperienceID')),
            'fields_of_study_all'=>json_encode($educationExperience->where('UserID',$request->user()->id)->pluck('fields_of_study')),
            'university_grad_year'=>  (str_contains($request->degree, 'Bachelor') || str_contains($request->degree, "Bachelor's")) ? date('m/y',strtotime($request->graduation_year)) : null,
            'most_recent_degree'=>$request->degree,
            'most_recent_school'=>$request->school,
        ]);

        return $this->respondSuccessWithData(EducationExperienceResource::collection($educationExperience->where('UserID',$request->user()->id)->get()),'Education Experience',200);
    }

    public function edit(Request $request){    
        $request->validate([
            'id' => 'required|integer|exists:education_experiences,EducationExperienceID',
            
        ],
        [
            'id.exists'=>'The Given id is invalid.'
        ]);
        $education=DB::table('education_experiences')->where('EducationExperienceID',$request->id)->where('UserId',$request->user()->id);
        if($education->first())
        {
            return $this->respondWithResource(new EducationExperienceResource($education->first()),'Education Experience Details',200);
        }

        return $this->respondNotContentOwner();
    }

    public function update(Request $request){
        
        $request->validate([
            'id' => 'required|integer|exists:education_experiences,EducationExperienceID',
            'school' => 'required|string',
            'degree' => 'required|string',
            'fields_of_study' => 'required|array',
            'graduation_year' => 'required|date',
        ],
        [
            'id.exists'=>'The Given id is invalid.'
        ]);
        $education=DB::table('education_experiences')->where('EducationExperienceID',$request->id)->where('UserId',$request->user()->id);
        if($education->first())
        {
            $timestamp_est=Carbon::parse(now(),'EST')->setTimeZone('EST');
            $education->update(
                [
                    'school'=>$request->school,
                    'degree'=>$request->degree,
                    'fields_of_study'=>json_encode($request->fields_of_study),
                    'graduation_year'=>date('m/y',strtotime($request->graduation_year)),
                    'Modified_timestamp_EST'=>$timestamp_est,
                ]
            );
            $advisee=DB::table('advisees')->where('UserID',$request->user()->id);
            $advisee->update([            
                'most_recent_degree'=>$request->degree,
                'most_recent_school'=>$request->school,
            ]);
            $educations=DB::table('education_experiences')->where('UserID',$request->user()->id)->get();
            return $this->respondWithResource(EducationExperienceResource::collection($educations),'Education Experience Details',200);
        }

        return $this->respondNotContentOwner();
    }

    public function destroy(Request $request)
    {
        $request->validate([
            'id' => 'required|integer|exists:education_experiences,EducationExperienceID',
        ],
        [
            'id.exists'=>'The Given id is invalid.'
        ]);

        $education=DB::table('education_experiences')->where('EducationExperienceID',$request->id)->where('UserId',$request->user()->id);
        if($advisee_education=$education->first())
        {
            
            $advisee=DB::table('advisees')->where('UserID',$request->user()->id);
            
            $educations=DB::table('education_experiences')->where('UserID',$request->user()->id)->get();
            $adviseeInfo=$advisee->first();
            $advisee->update([            
                'education_experiences'=>json_encode($educations->pluck('EducationExperienceID')),
                'fields_of_study_all'=>json_encode($educations->pluck('fields_of_study')),
                'most_recent_degree'=>($adviseeInfo->most_recent_degree==$advisee_education->degree) ? null : $adviseeInfo->most_recent_degree,
                'most_recent_school'=>($adviseeInfo->most_recent_school==$advisee_education->school) ? null : $adviseeInfo->most_recent_school,
            
            ]);
            $education->delete();
            $educations=DB::table('education_experiences')->where('UserID',$request->user()->id)->get();
            return $this->respondWithResource(EducationExperienceResource::collection($educations),'Education Experience Details',200);
        }
        return $this->respondNotContentOwner();
    }

    public function addHighestDegree(Request $request)
    {
        
        $request->validate([
            'highest_degree' => 'required|string',
        ]);
        $advisee=DB::table('advisees')->where('UserID',$request->user()->id);
        $advisee->update([            
            'highest_degree_completed'=>$request->highest_degree,
        ]);

        return $this->respondSuccess('Highest Degree Added Successfully !' ,201);
    }
}
