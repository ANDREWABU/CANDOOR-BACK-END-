<?php

namespace App\Http\Controllers\Api\V2\Advisee;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Traits\Helpers\ApiResponseTrait;

class SubmissionController extends Controller
{
    use ApiResponseTrait;
    
    public function submit(Request $request)
    {
     
            $here_about_us = array(
                "0" => "LinkedIn",
                "1" => "Other Social Media",
                "2" => "Friend",
                "3" => "Colleague",
                "4" => "Search Engine",
                "5" => "School Career Office",
                "6" => "Blog or Article",
                "7" => "Partner Organization",
                "8" => "Employer",
                "9" => "Other",
                "10" => "Know a Founder Personally"
            );
            
            $data=[
                'here_about_us' =>$here_about_us,
               
            ];
            if($request->user()->hasRole('Advisor')){
                $advisor=DB::table('advisors')->where('UserID',$request->user()->id);
                $advisor->update([            
                    'signup_career_completed_timestamp_EST'=>Carbon::parse(now(),'EST')->setTimeZone('EST'),
                    'funnel_status'=>'Email Verified',
                    'signup_submitted_timestamp_EST'=>Carbon::parse(now(),'EST')->setTimeZone('EST'),
                ]);
                return $this->respondSuccessWithData($data, "Submission Completed Successfully!",200);
    
            }elseif($request->user()->hasRole('Advisee')){
                
                $advisee=DB::table('advisees')->where('UserID',$request->user()->id);
                $advisee->update([            
                    'signup_career_completed_timestamp_EST'=>Carbon::parse(now(),'EST')->setTimeZone('EST'),
                    'funnel_status'=>'Submission Successfully',
                    'signup_submitted_timestamp_EST'=>Carbon::parse(now(),'EST')->setTimeZone('EST'),
                ]);
        
                return $this->respondSuccessWithData($data,"Submission Completed Successfully!",200);
            }
            
            
        }
        public function SubmitApplyData(Request $request)
        {
            
            
            if($request->user()->hasRole('Advisor')){
                
                $advisor=DB::table('advisors')->where('UserID',$request->user()->id);
                $advisor->update([            
                    'actively_hiring_confirmation'=> $request->is_prescrean_program,
                    'hear_about_us'=> $request->how_hear_us,
                    'referral_code'=> $request->referralCode,
                ]);
                return $this->respondSuccess("Submission Completed Successfully!",200);
    
            }elseif($request->user()->hasRole('Advisee')){
               
                $advisee=DB::table('advisees')->where('UserID',$request->user()->id);
                $advisee->update([            
                    'apply_notes'=> json_encode($request->belongs_to),
                    'hear_about_us'=> $request->how_hear_us,
                    'referral_code'=> $request->referralCode,
                ]);
        
                return $this->respondSuccess("Submission Completed Successfully!",200);
            }
        }
    }
