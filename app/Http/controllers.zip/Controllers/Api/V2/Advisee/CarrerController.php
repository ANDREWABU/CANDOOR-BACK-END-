<?php

namespace App\Http\Controllers\Api\V2\Advisee;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\AddUserCarrerGoalRequest;
use Illuminate\Http\Request;
use App\Http\Resources\WorkRoleResource;
use App\Http\Resources\CompanyResource;
use App\Http\Resources\IndustryResource;
use App\Http\Traits\Helpers\ApiResponseTrait;
use Illuminate\Support\Facades\DB;
use App\Http\Resources\UserCarrerGoalResource;
use App\Models\Advisee;
use App\Models\CarrerGoal;

class CarrerController extends Controller
{
     use ApiResponseTrait;

    public function getDataForCarrer(Request $request)
    {
        $advisee=DB::table('advisees')->where('UserID',$request->user()->id);
        if(!$advisee->first())
        {
            $this->respondUnAuthorized();
        }
        $work_roles = DB::table('work_roles')->get();
        $industries = DB::table('industries')->get();
        $companies = DB::table('companies')->get();
        $employment_opportunities = array("0" => "Yes; I’m actively looking for full-time roles","1" => "Yes; I’m actively looking for part-time / internship roles", "2" => "Maybe; I’m casually browsing","3" => "No; I’m not interested in employment opportunities at this time");

        $data=[
            'work_roles' =>new WorkRoleResource($work_roles),
            'industries' =>new IndustryResource($industries),
            'companies' =>new CompanyResource($companies),
            'user_carrer' =>new UserCarrerGoalResource($advisee->first()),
            'employment_opportunities' => $employment_opportunities,
        ];
        
        $advisee->update([
            'funnel_status'=>'Career Goals Complete',
        ]);
        return $this->respondSuccessWithData($data,'companies , industries ,work_roles Listing',200);
    }

    public function addUserCarrerGoal(AddUserCarrerGoalRequest $request)
    {
        // $carrer_goal =new CarrerGoal();
        // $carrer_goal->updateOrCreate(['UserID'=>$request->user()->id],[
        //     'next_carrer_goals'=>$request->next_carrer_goals,
        //     'support_in_achievement'=>$request->support_in_achievement,
        //     'roles'=>json_encode($request->roles),
        //     'industries'=>json_encode($request->industries),
        //     'companies'=>json_encode($request->companies),
        //     'excited_topics'=>json_encode($request->excited_topics),
        //     'employment_opportunities'=>$request->employment_opportunities ?? '',
        //     'is_prescrean_program'=>$request->is_prescrean_program ?? 0,
        // ]);
        
        $advisee=DB::table('advisees')->where('UserID',$request->user()->id);
        $adviseeInfo=$advisee->first();
        $advisee->update([
            'initial_career_goals'=>(empty($adviseeInfo->initial_career_goals)) ? $request->next_carrer_goals : $adviseeInfo->initial_career_goals,
            'current_career_goals'=>(!empty($adviseeInfo->initial_career_goals)) ? $request->next_carrer_goals : null,
            'job_search_status'=>$request->employment_opportunities ?? '',
            'prescreening_program_opt_in'=>$request->is_prescrean_program ?? 0,
            'why_joined'=>$request->why_joined ?? '',
            'dream_roles'=>json_encode($request->dream_roles),
            'dream_industries'=>json_encode($request->dream_industries),
            'services_requested'=>json_encode($request->excited_topics),
            'dream_companies'=>json_encode($request->dream_companies),
        ]);
        $advisee=DB::table('advisees')->where('UserID',$request->user()->id)->first();
        
        return $this->respondWithResource(new UserCarrerGoalResource($advisee),'Advisee Carrer Goals',200);
    }

    public function getUserCarrerGoal(Request $request)
    {
        $advisee=DB::table('advisees')->where('UserID',$request->user()->id)->first();
        if($advisee)
        {
            return $this->respondSuccessWithData(new UserCarrerGoalResource($advisee),'User Carrer Goals',200);
        }
        $this->respondUnAuthorized();
       

    }
}
