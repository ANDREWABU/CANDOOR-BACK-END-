<?php

namespace App\Http\Controllers\Api\V2\Advisor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\Api\AddBackgroundStepRequest;
use App\Http\Traits\Helpers\ApiResponseTrait;
use App\Models\UserBackground;
use App\Http\Resources\UserBackgroundResource;

class BackgroundController extends Controller
{
    use ApiResponseTrait;

    public function getDataForBackground(Request $request)
    {
        $countries = DB::table('countries')->get();
        $timezones = DB::table('time_zones')->get();
        $states = DB::table('states')->get();
        $race_ethnicities = DB::table('race_ethnicities')->get();
        $usa_states=DB::table('states')->get();
        $background =UserBackground::where('UserID',$request->user()->id)->first();

        $gender = array("0" => "Male","1" => "Female", "2" => "Non-binary","3" =>"Prefer not to answer");
        $identity = array("0"=>"A first-generation college student","1" => "From a low-income family", "2" => "A member or former member of the U.S. Armed Forces","3" => "LGBTQ+","4" => "Disabled","5" => "Prefer not to answer");
       
        $data=[
            'countries' =>$countries,
            'timezones' =>$timezones,
            'states' => $states,
            'race_ethnicities' =>$race_ethnicities,
            'user_background' =>$background,
            'usa_states' =>$usa_states,
            'gender' => $gender,
            'identity' => $identity,
        ];
        $advisors=DB::table('advisors')->where('UserID',$request->user()->id);
        $advisors->update([
            'funnel_status'=>'Background Info Complete',
        ]);
        return $this->respondSuccessWithData($data,'Countries , Timezones ,Race Ethinicities Listing',200);
    }

    public function addUserBackground(AddBackgroundStepRequest $request)
    {
        $background =new UserBackground();
        $background->updateOrCreate(['UserID'=>$request->user()->id],[
            'country'=>$request->country,
            'city'=>$request->city,
            'state'=>$request->state,
            'time_zone'=>$request->time_zone,
            'gender'=>$request->gender,
            'race'=>json_encode($request->race),
            'belongs_to'=>json_encode($request->belongs_to),
        ]);
        
        $background=$background->where('UserID',$request->user()->id)->first();
        return $this->respondWithResource(new UserBackgroundResource($background),'User Background',200);
    }

    public function getUserBackground(Request $request)
    {
        $background =UserBackground::where('UserID',$request->user()->id)->first();
        if($background)
        {
            return $this->respondSuccessWithData(new UserBackgroundResource($background),'User Background',200);
        }

        return $this->respondNoContent('User Carrer Goals',200);
    }
}
