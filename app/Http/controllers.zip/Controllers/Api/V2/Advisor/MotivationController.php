<?php

namespace App\Http\Controllers\Api\V2\Advisor;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Advisor\MotivationRequest;
use App\Http\Resources\Advisor\MotivationResource;
use App\Http\Traits\Helpers\ApiResponseTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MotivationController extends Controller
{
    use ApiResponseTrait;

    public function index(Request $request)
    {
        $advisor=DB::table('advisors')->where('UserID',$request->user()->id);
        if(!$advisor->first())
        {
            $this->respondUnAuthorized();
        }
        $data=[
            'motivation' =>new MotivationResource($advisor->first()),
        ];
        $advisor->update([
            'funnel_status'=>'Background info Complete',
        ]);
        return $this->respondSuccessWithData($data,'Advisor Motivation Data',200);
    }

    public function addUserMotivationData(MotivationRequest $request)
    {
        
        $advisor=DB::table('advisors')->where('UserID',$request->user()->id);
        $advisorInfo=$advisor->first();
        if(!$advisorInfo)
        {
            $this->respondUnAuthorized();
        }
        $advisor->update([
            
            'prescreening_program_opt_in'=>$request->is_prescrean_program ?? 0,
            'joining_reason'=>$request->why_joined ?? '',
            'prior_experience'=>$request->prior_experience,
        ]);
        return $this->respondWithResource(new MotivationResource($advisorInfo),'Advisor Motivation Data',200);
    }
}
