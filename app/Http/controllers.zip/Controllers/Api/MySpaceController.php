<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Api\MentorAvailability;
use App\Models\CareerSpace;
use App\Models\Day;
use App\Models\User;
use Illuminate\Http\Request;
use App\Models\Api\MySpace;
use Helpers;

class MySpaceController extends Controller
{
    //

    public function index()
    {
        $user_id = Auth('api')->id();
        $spaces = MySpace::where('user_id',$user_id)->with('spaces')->orderBy('id','DESC')->get();
        return Helpers::sendResponseBack($spaces,'mySpaces', 'Spaces successfully retrieved', 'No Data Found');
    }

    public function store(Request $request)
    {
        $request->validate([
            'space_id' => 'required',
        ]);
        $user_id = Auth('api')->id();
        $spaces = MySpace::updateOrCreate([
            'user_id' => $user_id,
            'career_space_id' => $request->space_id
        ]);
        $mySpace = MySpace::where('user_id',$user_id)->with('spaces')->get();
        if($spaces->wasRecentlyCreated){
            return Helpers::sendResponseBack($mySpace,'mySpaces', 'Spaces successfully Created', 'No Data Found');
        }else{
            return Helpers::sendResponseBack($mySpace,'mySpaces', 'Spaces successfully Updated', 'No Data Found');
        }

    }


    public function recommendedMentors(Request $request){

        $user_id = auth('api')->id();
        $userSpaceId = MySpace::where('user_id',$user_id)->pluck('career_space_id')->first();
        if($userSpaceId)
        {
            $mentors = CareerSpace::where('id',$userSpaceId)->with(['users' => function($q) use($userSpaceId)
            {
                $q->whereHas('roles' ,function($q) use($userSpaceId)
                {
                    $q->where('name','Mentor');

                })->mentorInformation()
                    ->with(['mentorExpertise.expertise_details','careerSpaces','mentorAvailability','zone']);
            }])->first();
        }


        return Helpers::sendResponseBack($mentors,'RecommendedMentors', 'Recommended Mentors Successfully Fetch', 'No Data Found');

    }

    public function mentorBySpace(Request $request){

            $mentorsBySpace = CareerSpace::with(['users' => function($q)
            {
                $q->whereHas('roles' ,function($q)
                {
                    $q->where('name','Mentor');

                })->mentorInformation()->with(['zone','mentorExpertise.expertise_details','careerSpaces','mentorAvailability']);

            }])->when(request('space_title'),function($q) use($request)
            {
                $q->where('title', 'like', '%' . request('space_title') . '%');

            })->first();


        return Helpers::sendResponseBack($mentorsBySpace,'RecommendedMentors', 'Mentors Successfully Fetch', 'No Data Found');

    }

    public function mentorSessions(Request $request) {

       $mentorSessions = User::where('id',$request->id)->whereHas('roles', function ($q) {
           $q->where('name', 'Mentor');
       })->with(['mentorExpertise.expertise_details','mentorAvailability.day','mentorAvailability.zone','zone'])->first();

        return Helpers::sendResponseBack($mentorSessions,'MentorSessions', 'MentorSessions Successfully Fetch', 'No Data Found');

    }






}
