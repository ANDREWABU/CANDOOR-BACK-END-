<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Api\JobPostDetail;
use Helpers;


class JobPostDetailsController extends Controller
{
    //
    public function index()
    {

    }
    public function Store(Request $request)
    {
        $validate = $request->validate([
            "post_id" => "required",
            "type_of_employment" => "required",
            "contract_type" => "required",
            "start_date" => "required",
            "compensation" => "required",
            "start_price" => "required",
            "end_price" => "required",
            "salary_type" => "required",
            "description" => "required",
            "aditional_description" => "required",
        ]);
        $user_id = Auth('api')->id();
        $jobDetails = JobPostDetail::updateOrCreate(['user_id' =>$user_id, 'post_id' => $request->post_id],[
            'type_of_employment' => $request->type_of_employment,
            'contract_type' => $request->contract_type,
            'start_date' => $request->start_date,
            'compensation' => $request->compensation,
            'start_price' => $request->start_price,
            'end_price' => $request->end_price,
            'salary_type' => $request->salary_type,
            'description' => $request->description,
            'aditional_description' => $request->aditional_description,
        ]);
        return Helpers::sendResponseBack($jobDetails,'jobDetails', 'Job Post Details successfully created', 'Something Went wrong please try again');
    }

    public function update(Request $request, $id)
    {
        $validate = $request->validate([
            "type_of_employment" => "required",
            "contract_type" => "required",
            "start_date" => "required",
            "compensation" => "required",
            "start_price" => "required",
            "end_price" => "required",
            "salary_type" => "required",
            "description" => "required",
            "aditional_description" => "required",
        ]);
        $user_id = Auth('api')->id();
        $jobDetails = JobPostDetail::where(['id' => $id, 'user_id' => $user_id])->update($validate);
        return Helpers::sendResponseBack($jobDetails,'jobDetails', 'Job Post Details successfully created', 'Something Went wrong please try again');
    }

}
