<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Api\JobPostCompanyInfo;
use Helpers;

class JobPostCompanyInfoController extends Controller
{
    //
    public function store(Request $request)
    {
        $validate = $request->validate([
            "post_id" => "required",
            "company_size" => "required",
            "hear_about_us_id" => "required",
            "name" => "required",
            "company_name" => "required",
            "phone_no" => "required",
        ]);
        $user_id = Auth('api')->id();
        $data = JobPostCompanyInfo::updateOrCreate(['user_id' => $user_id, 'post_id' => $request->post_id],[
            'company_size' => $request->company_size,
            'hear_about_us_id' => $request->hear_about_us_id,
            'name' => $request->name,
            'company_name' => $request->company_name,
            'phone_no' => $request->phone_no,
        ]);
        return Helpers::sendResponseBack($data,'companyInfo', 'Company info successfully created', 'Something Went wrong please try again');

    }

    public function update(Request $request,$id)
    {
        $validate = $request->validate([
            "company_size" => "required",
            "hear_about_us_id" => "required",
            "name" => "required",
            "company_name" => "required",
            "phone_no" => "required",
        ]);
        $user_id = Auth('api')->id();
        $data = JobPostCompanyInfo::where(['id' => $id, 'user_id' => $user_id])->update($validate);
        return Helpers::sendResponseBack($data,'companyInfo', 'Company info successfully created', 'Something Went wrong please try again');

    }
}
