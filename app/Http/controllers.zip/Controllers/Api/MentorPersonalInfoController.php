<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Api\MentorPersonalInfoRepo;
use App\Models\Api\PersonalInformation;
use App\Models\User;
use Helpers;


class MentorPersonalInfoController extends Controller
{
    /**
     * Auth Umar
    */

    /**
     * Repository
     * @var App\Repositories\Api\MentorPersonalInfoRepo;
     */
    protected $repo;

    public function __construct(MentorPersonalInfoRepo $repo)
    {
        $this->repo = $repo;
    }
    public function index()
    {
        $user_id = Auth('api')->id();
        $response = PersonalInformation::where('user_id',$user_id)->with("country")->with("city")->get();
        return Helpers::sendResponseBack($response,'personalInfo', 'Mentor personal Information successfuly fetch', 'Mentor personal information not found');
    }

    public function store(Request $request)
    {
        $user_id = Auth('api')->id();
        $validate = $request->validate([
            'email'=>'required',
            'country'=>'required',
            'description'=>'required',
        ]);
        User::where('id',Auth('api')->id())->update(['profile_filled' => 1]);
        $response = $this->repo->insertData($request->all(),$user_id);
        if($response->wasRecentlyCreated){
            return Helpers::sendResponseBack($response,'personalInfo', 'Mentor personal Information successfuly inserted', 'Something Went wrong please try again');
        }else{
            return Helpers::sendResponseBack($response,'personalInfo', 'Mentor personal Information successfuly updated', 'Something Went wrong please try again');
        }
    }
    public function destroy($id)
    {
        $response = $this->repo->delete($id);
        return Helpers::sendResponseBack($response,'personalInfo', 'Mentor personal Information successfuly deleted', 'Mentor personal information data not exist against this id='.$id);
    }

    public function mentorInfo(){

        $user_id = auth('api')->id();
        $data = User::where('id',$user_id)->mentorInfo()->get()->toArray();
        return response()->json([
            'status' =>200,
            'success'=>'Record Successfully Fetch',
            'userInfo'=> $data
        ]);
    }
}
