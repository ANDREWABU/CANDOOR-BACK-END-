<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Repositories\Api\MentorExpertiseRepo;
use App\Models\Api\MentorExpertise;
use App\Models\Api\MentorExpertiseDetail;
use Illuminate\Http\Request;
use App\Models\User;
use Helpers;

class MentorExpertiseController extends Controller
{
    /**
     * Auth Umar
     */

    /**
     * Repository
     * @var App\Repositories\Api\MentorExpertiseRepo;
     */
    protected $repo;

    public function __construct(MentorExpertiseRepo $repo)
    {
        $this->repo = $repo;
    }

    public function index(Request $request)
    {
        $user_id = Auth('api')->id();
        $response = $this->repo->where('mentor_id', $user_id)->with('expertise_details')->get();
        return Helpers::sendResponseBack($response,'expertise', 'Expertise details successfully retrieved', 'Something Went wrong please try again');
        // dd($response);
    }
    public function store(Request $request)
    {
        $user_id = Auth('api')->id();
        $validate = $request->validate([
            'expertise' => 'required',
            'workExp' => 'required',
        ]);
        User::where('id',Auth('api')->id())->update(['profile_filled' => 1 ]);
        $response = $this->repo->storeExpertiseDetails($request->all());
        return Helpers::sendResponseBack($response,'expertise', 'Expertise details successfully retrieved', 'Something Went wrong please try again');
    }

    public function expertiseDetailsDestroy($id)
    {
        $details = MentorExpertiseDetail::destroy($id);
        return Helpers::sendResponseBack($details,'expertise', 'Expertise details successfully deleted', 'Something Went wrong please try again');
    }
}
