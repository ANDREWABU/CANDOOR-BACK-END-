<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Api\Skill;
use App\Models\User;

class MenteeSkillsController extends Controller
{
    public function index()
    {
        $getskill = Skill::where('mentee_id', Auth('api')->id())->get();

        return response()->json([
            'status' => 200,
            'success' => 'Skill Successfully fetch',
            'skills' => $getskill,
        ]);

    }

    public function store(Request $request)
    {
        $request->validate([
            'skill' => 'required',
        ]);
        $user_id = Auth('api')->id();
        // Check if data find then delete
        $check = Skill::where('mentee_id', $user_id)->delete();
        // insert data
        foreach ($request->skill as $key => $val) {
            Skill::insert([
                'mentee_id' => $user_id,
                'skill' => $val['skill'],
                'strength' => $val['strength'],
            ]);
        }
        User::where('id',Auth('api')->id())->update(['profile_filled' => 1 ]);
        return response()->json([
            'status' => 200,
            'Success' => 'Record Successfully save',
            'skills' => Skill::where('mentee_id', $user_id)->get(),
        ]);

    }

    public function destroy(Skill $skill)
    {
        $skill->delete();

        return response()->json([
            'status' => 200,
            'success' => 'Record Successfully Deleted',
        ]);

    }

    public function addSkill(Request $request)
    {
        $request->validate([
            'skill' => 'required',
            'strength' => 'required',
        ]);
        $user_id = Auth('api')->id();
        $data = Skill::updateOrCreate([
            'mentee_id' => $user_id,
            'skill' => $request->skill,
        ],[
            'strength' => $request->strength
        ]);
        return response()->json([
            'status' => 200,
            'Success' => 'Record Successfully save',
            'skills' => $data,
        ]);
    }
}
