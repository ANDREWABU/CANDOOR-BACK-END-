<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Api\EducationDetail;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class MenteeEducationDetailController extends Controller
{
    public function index()
    {
        $geteducation = EducationDetail::where('mentee_id', Auth('api')->id())->get();
        return response()->json([
            'status' => 200,
            'success' => 'EducationDetail Successfully fetch',
            'educationDetails' => $geteducation,
        ]);
    }
    public function show($id)
    {
        $geteducation = EducationDetail::find($id);
        return response()->json([
            'status' => 200,
            'success' => 'EducationDetail Successfully fetch',
            'educationDetails' => $geteducation,
        ]);
    }

    public function store(Request $request)
    {
        Validator::make($request->all(), [
            'educationDetail' => 'required',
        ])->validate();
        $user_id = Auth('api')->id();

        EducationDetail::where('mentee_id', $user_id)->delete();

        foreach ($request->educationDetail as $key => $val) {
            EducationDetail::insert([
                'mentee_id' => $user_id,
                'degree_title' => $val['degree_title'],
                'degree_level' => $val['degree_level'],
                'institute' => $val['institute'],
                'location' => $val['location'],
                'year_completion' => $val['year_completion'],
                'type' => $val['type'],
                'marks' => $val['marks'],
            ]);
        }
        User::where('id',Auth('api')->id())->update(['profile_filled' => 1 ]);
        return response()->json([
            'status' => 200,
            'success' => 'EducationDetail successfully saved',
            'educationDetails' => EducationDetail::where('mentee_id', $user_id)->get(),
        ]);

    }
    public function destroy(EducationDetail $educationDetail)
    {

        $educationDetail->delete();

        return response()->json([
            'status' => 200,
            'success' => 'Record Successfully Deleted',
        ]);
    }

    public function addEducation(Request $request)
    {
        $validate = $request->validate([
            'degree_title' => 'required',
            'degree_level' => 'required',
            'institute' => 'required',
            'location' => 'required',
            'year_completion' => 'required',
            'type' => 'required',
            'marks' => 'required'
        ]);
        $user_id = Auth('api')->id();
        $data = EducationDetail::updateOrCreate([
            'mentee_id' => $user_id,
            'degree_title' => $request->degree_title,
            'degree_level' => $request->degree_level,
            'year_completion' => $request->year_completion,
        ],[
            'institute' => $request->institute,
            'location' => $request->location,
            'type' => $request->type,
            'marks' => $request->marks
        ]);
        return response()->json([
            'status' => 200,
            'success' => 'EducationDetail successfully saved',
            'educationDetails' => $data,
        ]);

    }
    public function editEducation($id, Request $request)
    {
        $validate = $request->validate([
            'degree_title' => 'required',
            'degree_level' => 'required',
            'institute' => 'required',
            'location' => 'required',
            'year_completion' => 'required',
            'type' => 'required',
            'marks' => 'required'
        ]);
        $data = EducationDetail::where('id',$id)->update($validate);
        return response()->json([
            'status' => 200,
            'success' => 'EducationDetail successfully saved',
            'educationDetails' => $data,
        ]);
    }
}
