<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Api\PersonalInformation;
use App\Models\TimeZone;
use App\Models\User;
use Helpers;
use Illuminate\Http\Request;

class MenteeSettingController extends Controller
{
    //
    public function profileSetting(Request $request)
    {
        $request->validate([
            'country' => 'required',
            'city' => 'required',
            'date_of_birth' => 'required',
            'gender' => 'required',
            'first_name' => 'required',
            'last_name' => 'required',
            'timeZone' => 'required',
        ]);
        $user_id = Auth('api')->id();
        $image_path = '';
        if (!empty($request->image)) {
            $image = $request->image; // your base64 encoded
            $extension = explode('/', explode(':', substr($image, 0, strpos($image, ';')))[1])[1];
            $replace = substr($image, 0, strpos($image, ',') + 1);
            $image = str_replace($replace, '', $image);
            $image_path = Helpers::makeNewDirectory('users/' . $user_id . '/profile_image');
            if (!$image_path) {
                $image_path = 'users/' . $user_id . '/profile_image';
            }
            $image_path = $image_path . '/' . time() . '.' . $extension;
            $path = \Storage::disk('public_uploads')->put($image_path, base64_decode($image));
        }

        $timeZone = TimeZone::updateOrCreate(
            [
            "user_id" => $user_id
            ],
            [
            "abbrev" => $request->timeZone['abbrev'],
            "altName" => $request->timeZone['altName'],
            "label" => $request->timeZone['label'],
            "offset" => $request->timeZone['offset'],
            "value" => $request->timeZone['value'],
        ]);
        $data = PersonalInformation::updateOrCreate([
            'user_id' => $user_id,
        ], [
            'time_zone_id' => $timeZone->id,
            'city' => $request->city,
            'country' => $request->country,
            'date_of_birth' => $request->date_of_birth,
            'gender' => $request->gender,
            'profile_image' => 'uploads/'.$image_path,
            'display_name' =>$request->display_name
        ]);
        User::where('id', $user_id)->update(['first_name' => $request->first_name, 'last_name' => $request->last_name]);

        return Helpers::sendResponseBack($data, 'profile', 'Profile detail successfully created', 'Something Went wrong please try again');
    }
}
