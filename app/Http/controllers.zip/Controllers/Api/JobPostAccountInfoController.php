<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Api\JobPostAccountInfo;

class JobPostAccountInfoController extends Controller
{
    //
    public function store(Request $request)
    {
        $request->validate([
            "post_id" => "required",
        ]);
    }
}
