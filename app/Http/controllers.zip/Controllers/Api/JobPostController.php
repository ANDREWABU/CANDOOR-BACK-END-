<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Api\JobPost;
use Helpers;
use Illuminate\Http\Request;

class JobPostController extends Controller
{
    public function index()
    {
        $user_id = Auth('api')->id();
        // \DB::enableQueryLog();
        $jobPost = JobPost::relations()->where('user_id', $user_id)->relations()->paginate(10);
        // dd(\DB::getQueryLog());
        // dd($jobPost);
        return Helpers::sendResponseBack($jobPost, 'jobLists', 'Job Post successfully retrieved', 'Something Went wrong please try again');

    }

    public function show($id)
    {
        $user_id = Auth('api')->id();
        $jobPost = JobPost::relations()->where(['id' => $id, 'user_id' => $user_id])->get()->toArray();
        return Helpers::sendResponseBack($jobPost, 'jobLists', 'Job Post successfully retrieved', 'Something Went wrong please try again');

    }

    public function store(Request $request)
    {
        $validate = $request->validate([
            "company_name" => "required",
            "user_role_id" => "required",
            "hiring_budget" => "required",
            "job_title" => "required",
            "city_id" => "required",
            "country_id" => "required",
            "post_lang_id" => "required",
            "job_working_type" => "required",
            "how_many_hires" => "required",
        ]);
        if ($request->post_id && !empty($request->post_id)) {
            JobPost::find($request->post_id)->companyInfo()->delete();
            // JobPostCompanyInfo::where('post_id',$request->post_id)->delete();
            // JobPostDetail::where('post_id',$request->post_id)->delete();
        }
        // dd($validate);

        $user_id = Auth('api')->id();
        $data = JobPost::create(array_merge($validate, ['user_id' => $user_id, 'always_hiring' => $request->always_hiring]));

        return Helpers::sendResponseBack($data, 'jobPost', 'Job Post successfully created', 'Something Went wrong please try again');
    }

    public function multiplePostDelete(Request $request)
    {
        $request->validate([
            'ids' => 'required|array',
        ]);
        $response = JobPost::destroy($request->ids);
        return Helpers::sendResponseBack($response, 'jobPost', 'Job Post successfully created', 'Something Went wrong please try again');

    }

    public function searchFilter(Request $request)
    {
        $user_id = Auth('api')->id();
        $jobPosts = JobPost::relations()->where('user_id', $user_id);
        if (!empty($request->active)) {
            $jobPosts->where('status', 1);
        }

        if (!empty($request->inActive)) {
            $jobPosts->where('status', 0);
        }
        if (!empty($request->featured)) {
            $jobPosts->where('status', 2);
        }
        if (!empty($request->search)) {
            $jobPosts->where('job_title', 'Like', '%' . $request->search);
        }

        if (!empty($request->sort)) {
            $jobPosts->orderBy('id', $request->sort);
        }

        $jobPosts = $jobPosts->relations()->paginate(10);
        return Helpers::sendResponseBack($jobPosts, 'jobLists', 'Job Post successfully retrieved', 'Something Went wrong please try again');
    }

    public function update(Request $request, $id)
    {
        $validate = $request->validate([
            "company_name" => "required",
            "user_role_id" => "required",
            "hiring_budget" => "required",
            "job_title" => "required",
            "city_id" => "required",
            "country_id" => "required",
            "post_lang_id" => "required",
            "job_working_type" => "required",
            "how_many_hires" => "required",
        ]);
        $user_id = Auth('api')->id();
        $data = JobPost::where(['id' => $id, 'user_id' => $user_id])->update(array_merge($validate, ['always_hiring' => $request->always_hiring]));

        return Helpers::sendResponseBack($data, 'jobPost', 'Job Post successfully created', 'Something Went wrong please try again');
    }

    public function getAllJobPosts()
    {
        $jobPost = JobPost::relations()->paginate(10);
        // dd(\DB::getQueryLog());
        // dd($jobPost);
        return Helpers::sendResponseBack($jobPost, 'jobLists', 'Job Post successfully retrieved', 'Something Went wrong please try again');

    }

    public function viewJob($id)
    {
        $jobPost = JobPost::relations()->where('id',$id)->get()->toArray();
        return Helpers::sendResponseBack($jobPost, 'jobLists', 'Job Post successfully retrieved', 'Something Went wrong please try again');

    }

    public function searchFilterMentee(Request $request)
    {
        $jobPosts = JobPost::relations();
        if (!empty($request->active)) {
            $jobPosts->where('status', 1);
        }

        if (!empty($request->inActive)) {
            $jobPosts->where('status', 0);
        }
        if (!empty($request->featured)) {
            $jobPosts->where('status', 2);
        }
        if (!empty($request->search)) {
            $jobPosts->where('job_title', 'Like', $request->search.'%');
        }

        if (!empty($request->sort)) {
            $jobPosts->orderBy('id', $request->sort);
        }

        $jobPosts = $jobPosts->relations()->paginate(10);
        return Helpers::sendResponseBack($jobPosts, 'jobLists', 'Job Post successfully retrieved', 'Something Went wrong please try again');
    }
}
