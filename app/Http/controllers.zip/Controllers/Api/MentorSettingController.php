<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Api\MentorPersonalInformation;
use App\Models\Api\PersonalInformation;
use App\Models\TimeZone;
use App\Models\User;
use Helpers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Symfony\Component\HttpFoundation\Request;

class MentorSettingController extends Controller
{
    public function mentorProfileSetting(Request $request)
    {

        $user_id = Auth('api')->id();

        $image_path = '';
        if (!empty($request->image)) {
            $image = $request->image; // your base64 encoded
            $extension = explode('/', explode(':', substr($image, 0, strpos($image, ';')))[1])[1];
            $replace = substr($image, 0, strpos($image, ',') + 1);
            $image = str_replace($replace, '', $image);
            $image_path = Helpers::makeNewDirectory('users/' . $user_id . '/profile_image');
            if (!$image_path) {
                $image_path = 'users/' . $user_id . '/profile_image';
            }
            $image_path = $image_path . '/' . time() . '.' . $extension;
            $path = \Storage::disk('public_uploads')->put($image_path, base64_decode($image));
        }

        $data = MentorPersonalInformation::updateOrCreate([
            'mentor_id' => $user_id,
        ], [
            'city' => $request->city,
            'country' => $request->country,
            'date_of_birth' => $request->date_of_birth,
            'gender' => $request->gender,
            'profile_image' => 'uploads/'.$image_path,
            'display_name' =>$request->display_name,
            'first_name' =>$request->first_name,
            'last_name' =>$request->last_name,
            'email' =>$request->email,
            'personal_information' =>$request->personal_information,
        ]);
        User::where('id', $user_id)->update(['first_name' => $request->first_name, 'last_name' => $request->last_name]);

        return Helpers::sendResponseBack($data, 'profile', 'Profile detail successfully created', 'Something Went wrong please try again');

    }


}
