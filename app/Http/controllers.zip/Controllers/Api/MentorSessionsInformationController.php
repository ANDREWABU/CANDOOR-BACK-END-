<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Api\SelectedSessions;
use Illuminate\Http\Request;

class MentorSessionsInformationController extends Controller
{
    public function totalMentees(){


    }
}
