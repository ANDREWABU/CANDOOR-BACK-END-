<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Api\WorkExperience;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class MenteeWorkExpController extends Controller
{
    public function index()
    {
        // \DB::enableQueryLog();
        $getmenteeWorkExperience = WorkExperience::where('mentee_id', Auth('api')->id())->with('country')->with('city')->get();
        // dd(\DB::getQueryLog());
        return response()->json([
            'status' => 200,
            'success' => 'WorkExperience successfully fetch',
            'WorkExperience' => $getmenteeWorkExperience,

        ]);

    }
    public function show($id)
    {
        $data = WorkExperience::where('id',$id)->with('country')->with('city')->get();
        return response()->json([
            'status' => 200,
            'success' => 'WorkExperience successfully fetch',
            'WorkExperience' => $data,

        ]);
    }
    public function store(Request $request)
    {
        Validator::make($request->all(), [
            'workExp' => 'required'
        ])->validate();
        $user_id = Auth('api')->id();
        WorkExperience::where('mentee_id', $user_id)->delete();
        foreach ($request->workExp as $key => $val) {
            WorkExperience::insert([
                'mentee_id' => $user_id,
                'job_title' => $val['job_title'],
                'company_name' => $val['company_name'],
                'country' => $val['country'],
                'city' => $val['city'],
                'start_date' => $val['start_date'],
                'end_date' => $val['end_date'],
            ]);
        }
        User::where('id',Auth('api')->id())->update(['profile_filled' => 1 ]);
        return response()->json([
            'status' => 200,
            'success' => 'WorkExperience successfully save',
            'WorkExperience' => WorkExperience::where('mentee_id', $user_id)->get(),
        ]);
    }

    public function destroy(WorkExperience $workExperience)
    {

        $workExperience->delete();

        return response()->json([
            'status' => 200,
            'success' => 'Record Successfully Deleted',
        ]);

    }

    public function addWorkExperience(Request $request)
    {
        $validate = $request->validate([
            "job_title" => "required",
            "company_name" => "required",
            "country" => "required",
            "city" => "required",
            "start_date" => "required",
            "end_date" => "required",
        ]);
        $user_id = Auth('api')->id();
        WorkExperience::updateOrCreate([
            'mentee_id' => $user_id,
            'job_title' => $request->job_title,
        ],[
            'company_name' => $request->company_name,
            'country' => $request->country,
            'city' => $request->city,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
        ]);
        return response()->json([
            'status' => 200,
            'success' => 'WorkExperience successfully save',
            'WorkExperience' => WorkExperience::where('mentee_id', $user_id)->get(),
        ]);

    }

    public function editWorkExp($id,Request $request)
    {
        $validate = $request->validate([
            "job_title" => "required",
            "company_name" => "required",
            "country" => "required",
            "city" => "required",
            "start_date" => "required",
            "end_date" => "required",
        ]);
        WorkExperience::where('id',$id)->update($validate);
        $user_id = Auth('api')->id();
        return response()->json([
            'status' => 200,
            'success' => 'WorkExperience successfully save',
            'WorkExperience' => WorkExperience::where('mentee_id', $user_id)->get(),
        ]);

    }
}
