<?php

namespace App\Http\Controllers\User;
use Mail;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    //
    public function contactUS(Request $request)
    {

        $rules=[
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
            'subject' => 'required',
            'message' => 'required',
        ];


        $this->validate($request,$rules);
        $html = 'First Name: '.$request->first_name.'<br>'.
                'Last Name: '.$request->last_name.'<br>'.
                'Email: '.$request->email.'<br>'.
                'Subject: '.$request->subject.'<br>'.
                'Message: '.$request->message;

//        try {
            Mail::send([], [], function ($message)  use($html){
                $message->to(env('MAIL_SUPPORT'))->subject('General Inquiries');
                $message->from(env("MAIL_FROM_ADDRESS", "support@candoor.com"), 'Candoor')
                    ->setBody($html, 'text/html');;
            });
//        }
//        catch(\Exception $e){
//            // Get error here
//            $responseData['data']= $e;
//            $responseData['status']=400;
//            $responseData['message']='oops something went wrong! Could not send email.';
//            return   response()->json($responseData, 200);
//
//        }
        $responseData['data']=[];
        $responseData['status']=200;
        $responseData['message']='Request has been processed.';
        return   response()->json($responseData, 200);
    }
}
